
#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include <vector>
#include <iomanip>
#include <ctime>
#include <cstdlib>

#ifndef UTILITY_H
#define UTILITY_H

void console_sleep()
{
    char z = 219;
    system("cls");
    system("color 04");
    std::cout << "\n\n\n\n\n\n\n\n\n\t\t\t\tPlease wait ";
    for (int i = 0; i <= 40; i++)
    {
        Sleep(40);
        std::cout << z;
    }
    system("color 7");
    system("cls");
}

struct student_data
{
    std::string name;
    std::string reg_no;
    std::string password;
    std::string dept;
    std::string messbill;
    std::string tuckbill;
    std::string laundrybill;
    bool isfound=false;
};


void readData(student_data* student,std::string filename)
{
    std::fstream id_data;
    
    std::string reg_no;
    std::cin.ignore();
    std::cout << "Enter Student Registeration Number: ";
    getline(std::cin, reg_no);
    
    id_data.open(filename, std::ios::in);
    std::string line;
    bool isFound = false;
    size_t comma1, comma2, comma3,comma4,comma5,comma6;
    console_sleep();
    while (getline(id_data, line))
    {
        if (line.find(reg_no) != std::string::npos)
        {
            
            comma1 = line.find(',');
            comma2 = line.find(',', comma1+1 );
            comma3 = line.find(',', comma2+1 );
            comma4 = line.find(',', comma3+1 );
            comma5 = line.find(',', comma4+1 );
            comma6 = line.find(',', comma5+1 );
            student->reg_no = line.substr(0, comma1);
            if (student->reg_no==reg_no)
            {
                student->name = line.substr(comma1+1, comma2 - comma1 -1);
                student->password = line.substr(comma2+1, comma3 - comma2 -1);
                student->dept = line.substr(comma3+1,comma4-comma3-1);
                student->messbill = line.substr(comma4+1, comma5 - comma4 -1);
                student->tuckbill = line.substr(comma5+1, comma6 - comma5 -1);
                student->laundrybill = line.substr(comma6+1);
                isFound=true;
                student->isfound = true;
                break;
            }
            else
            {
                continue;
            }   
        }
    }
    if (!isFound)
    {
        std::cout << "----------------" << std::endl;
        std::cout << "User not found!" << std::endl;
        std::cout << "----------------" << std::endl;
    }
    id_data.close();
}

#endif