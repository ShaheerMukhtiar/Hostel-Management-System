
#ifndef STUDENT_H
#define STUDENT_H


#include "utility.h"
#include "mess.h"
#include "laundry.h"
#include "OUTPASS.h"
#include "weekend.h"
#include "medical.h"
#include "room.h"

void passwordlocate(std::string filename) 
{
    student_data student;
    readData(&student,filename);
    std::string pass_word;
   
  
    bool isCorrect=false;
    int choice;
    while(!isCorrect)
    {
        
        std::cout << "Enter Password : ";
        getline(std::cin, pass_word);
        char choice;
        if(student.password==pass_word)
        {
            system("cls");
            std::string Choice;
            std::cout<<"\tWELCOME TO STUDENT MENU\n";
            isCorrect=true;
            std::cout<<"\n1.\tHostel Entry\n2.\tMess Management\n3.\tOutpass\n4.\tLaundry\n5.\tMedical Assistance\n6.\tRoom Allocation\n7.\tWeekend Transport\n\n\tYour Choice:";
            std::cin>>Choice;
            if(Choice =="1")
            {
                //code
            }
            else if(Choice =="2")
            {
                system("cls");
                mess(filename,student.reg_no);
            }
            else if(Choice=="3")
            {
                system("cls");
                Outpass();
            }
            else if(Choice=="4"){
                system("cls");
                Laundry(filename,student.reg_no,student.name);
            }
             else if(Choice=="5")
            {
                system("cls");
                Medical();
            }
             else if(Choice=="6")
            {
                system("cls");
                room();
            }
            else if(Choice=="7")
            {
                system("cls");
                weekend();
            }
            else
            {
                std::cout<<"Invalid Option.";
                system("cls");
            }
            
        }
        else
        {

            std::cout << "Incorrect password. "<<std::endl;
            std::cout << "Press 1: Try again" <<std::endl;
            std::cout << "Press 2: Forgetten password" <<std::endl;
            std::cout << "Press 3: Return to back to menu. "<<std::endl;
            std::cout << "Enter your choice. "<<std::endl;
            std::cin >> choice;
            if(choice=='1')
            {
                system("cls");
                
                continue;
                
            }
            else if (choice == '2')
            {
                /* code */
            }
            else if(choice=='3')
            {
                isCorrect=true;
                system("cls");
            }
            else 
            {
                std::cout << "Invalid output."<<std::endl;
            } 
        }    
    }    
}

void student(std::string filename)
{

    std::fstream id_datas;   
    student_data student;
    std::string pass_word;
    
    bool isFound = false;
    
    int x=0;
    char choice=0;
    while(x==0)
    {
        id_datas.open(filename, std::ios::in);
        std::string input_password;
        std::cout << "Press 1. To Enter Student Registeration Number  "<<std::endl;
        std::cout << "Press 2: Return to back to Main menu. "<<std::endl;
        std::cout << "Enter your choice: ";
        std::cin>>choice;
        if (choice=='1')
        {
            passwordlocate(filename);
            
        }
        else if(choice=='2')
        {
            console_sleep();
            system("cls");
            
            return;
        }
        else
        {
            std::cout << "Invalid output. "<<std::endl;
            system("cls");
        }
    }
    
}
#endif

