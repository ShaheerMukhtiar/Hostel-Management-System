#ifndef WEEKEND_H
#define WEEKEND_H

#include "utility.h"
#include "student.h"

void weekend_tpt(int *a,int *b);
void weekend_tpt (int *a, int *b)
{
    int opcode_w=0;
    std::cout<<"1: register your slot for upcoming trip\n2: check no. of people going\n0: exit\n";
    std::cout<<"Enter your choice: ";
    std::cin>>opcode_w;
    std::cout<<std::endl;
    switch(opcode_w)
    {   
    case 1:  
    {
        int opcode_a=0;
        std::cout<<"1: book your slot for Saturday\n2: book your slot for Sunday\n";
        std::cout<<"Enter your choice: ";
        std::cin>>opcode_a;
        std::cout<<std::endl;
        if(opcode_a==1)
        {
            *a+=1;
            std::cout<<"You have booked your slot for Saturday.Your seat number is: "<<*a;
        }
        else
        {
            *b+=1;
            std::cout<<"You have booked your slot for Sunday.Your seat number is: "<<*b;
        }
        std::cout<<".Bus will leave at 12:30pm and fall back at 5:00pm.\n";
    break;
    }
    case 2:  
    {
        int opcode_b=0;
        std::cout<<"1: check no. of students going on saturday\n2: check no. of students going on sunday\n";
        std::cout<<"Enter your choice: ";
        std::cin>>opcode_b;
        std::cout<<std::endl;
        if(opcode_b==1)
            std::cout<<*a<<" student(s) are going on Saturday.\n";
        else
            std::cout<<*b<<" student(s) are going on Sunday.\n";
        break;
    }
    case 0:  
    {
        break;
    }
    }    
}
void weekend()
{
    
    int opcode=0,sat_seat=0,sun_seat=0;
    do{
        std::cout<<"1: weekend transport facility\n0: exit\n";
        std::cout<<"Enter your choice: ";
        std::cin>>opcode;
        std::cout<<std::endl;
        if(opcode==1)
            weekend_tpt(&sat_seat,&sun_seat);
        else
            break;
    }while(opcode!=0);
   
}
#endif